import {sql,hash,send,validId} from "./_db.js";
export default async function handler(req,res){
 if(req.method!=="POST") return send(res,405,{error:"Method not allowed"});
 const {deviceId,key}=req.body||{};
 if(!validId(deviceId)||typeof key!=="string"||!/^SS-[A-F0-9]{16}$/.test(key)) return send(res,400,{error:"Invalid device ID or key"});
 try{
  await sql`INSERT INTO users(device_id) VALUES(${deviceId}) ON CONFLICT(device_id) DO NOTHING`;
  const cooldown=await sql`SELECT last_redeemed_at FROM users WHERE device_id=${deviceId}`;
  const last=cooldown[0]?.last_redeemed_at;
  if(last && Date.now()-new Date(last).getTime()<86400000) return send(res,429,{error:"REDEEM_COOLDOWN",redeemUntil:new Date(new Date(last).getTime()+86400000).toISOString()});
  const claimed=await sql`UPDATE issued_keys SET redeemed_by=${deviceId},redeemed_at=NOW() WHERE key_hash=${hash(key)} AND redeemed_by IS NULL RETURNING key_hash`;
  if(!claimed.length) return send(res,409,{error:"KEY_INVALID_OR_ALREADY_USED"});
  const updated=await sql`UPDATE users SET tickets=tickets+1,last_redeemed_at=NOW() WHERE device_id=${deviceId} RETURNING tickets,last_redeemed_at`;
  return send(res,200,{success:true,added:1,tickets:updated[0].tickets,redeemUntil:new Date(new Date(updated[0].last_redeemed_at).getTime()+86400000).toISOString()});
 }catch(e){return send(res,500,{error:"Redemption failed"});}
}