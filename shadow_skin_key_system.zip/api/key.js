import crypto from "node:crypto";
import {sql,hash,send,validId} from "./_db.js";
export default async function handler(req,res){
 if(req.method!=="POST") return send(res,405,{error:"Method not allowed"});
 const {deviceId}=req.body||{};
 if(!validId(deviceId)) return send(res,400,{error:"Invalid device ID"});
 try{
  const key="SS-"+crypto.randomBytes(8).toString("hex").toUpperCase();
  await sql`INSERT INTO issued_keys(key_hash) VALUES(${hash(key)})`;
  return send(res,200,{success:true,key});
 }catch(e){return send(res,500,{error:"Key generation failed"});}
}