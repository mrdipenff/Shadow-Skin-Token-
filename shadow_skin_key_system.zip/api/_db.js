import { neon } from "@neondatabase/serverless";
import crypto from "node:crypto";
export const sql=neon(process.env.DATABASE_URL);
export const hash=s=>crypto.createHash("sha256").update(s).digest("hex");
export function send(res,status,data){res.status(status).json(data);}
export function validId(s){return typeof s==="string" && /^[A-Za-z0-9_-]{16,128}$/.test(s)}