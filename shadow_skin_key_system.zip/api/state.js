import {sql,send,validId} from "./_db.js";
export default async function handler(req,res){
 if(req.method!=="POST") return send(res,405,{error:"Method not allowed"});
 const {deviceId}=req.body||{}; if(!validId(deviceId)) return send(res,400,{error:"Invalid device ID"});
 try{
  await sql`INSERT INTO users(device_id) VALUES(${deviceId}) ON CONFLICT(device_id) DO NOTHING`;
  const rows=await sql`SELECT tickets,last_redeemed_at,submit_until FROM users WHERE device_id=${deviceId}`;
  const u=rows[0],now=Date.now();
  return send(res,200,{tickets:u.tickets,redeemUntil:u.last_redeemed_at?new Date(new Date(u.last_redeemed_at).getTime()+86400000).toISOString():null,redeemCooldown:!!u.last_redeemed_at&&new Date(u.last_redeemed_at).getTime()+86400000>now,submitUntil:u.submit_until,submitCooldown:!!u.submit_until&&new Date(u.submit_until).getTime()>now});
 }catch(e){return send(res,500,{error:"State lookup failed"});}
}