import {sql,send,validId} from "./_db.js";
export default async function handler(req,res){
 if(req.method!=="POST") return send(res,405,{error:"Method not allowed"});
 const {deviceId}=req.body||{}; if(!validId(deviceId)) return send(res,400,{error:"Invalid device ID"});
 try{
  const rows=await sql`UPDATE users SET tickets=tickets-1,submit_until=NOW()+INTERVAL '24 hours' WHERE device_id=${deviceId} AND tickets>0 AND (submit_until IS NULL OR submit_until<=NOW()) RETURNING tickets,submit_until`;
  if(!rows.length) return send(res,409,{error:"NO_TICKET_OR_SUBMISSION_COOLDOWN"});
  return send(res,200,{success:true,tickets:rows[0].tickets,submitUntil:rows[0].submit_until});
 }catch(e){return send(res,500,{error:"Submission update failed"});}
}