CREATE TABLE IF NOT EXISTS users(device_id TEXT PRIMARY KEY,tickets INTEGER NOT NULL DEFAULT 0,last_redeemed_at TIMESTAMPTZ,submit_until TIMESTAMPTZ);
CREATE TABLE IF NOT EXISTS issued_keys(key_hash TEXT PRIMARY KEY,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),redeemed_by TEXT,redeemed_at TIMESTAMPTZ);
CREATE INDEX IF NOT EXISTS issued_keys_created_at_idx ON issued_keys(created_at);