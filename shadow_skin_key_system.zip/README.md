# Shadow Skin Key System

Deploy-ready starter for Vercel + Neon PostgreSQL. No admin panel.

## Deploy
1. Create a Neon PostgreSQL database.
2. Run `schema.sql` in the Neon SQL editor.
3. Upload this folder to a GitHub repository and import it into Vercel.
4. Set Vercel environment variable `DATABASE_URL` to the Neon connection string.
5. Deploy. The website URL is your key-generation website.

## API
- `POST /api/key` `{ "deviceId": "..." }` creates a random unique key.
- `POST /api/redeem` `{ "deviceId": "...", "key": "SS-..." }` redeems a key once and adds one ticket.
- `POST /api/state` `{ "deviceId": "..." }` reads ticket balance and cooldowns.
- `POST /api/complete-submit` `{ "deviceId": "..." }` deducts one ticket and starts the 24-hour submission cooldown.

## Important
The key is globally single-use: whoever redeems it first receives the ticket. Do not share keys.
The app must use a stable device ID on every call. The website's browser ID and Android app ID are not automatically the same; key transfer is allowed and the first app device to redeem it gets the ticket.
Tickets/cooldowns live in PostgreSQL and survive app Clear Data only if the same device ID is retained.
This starter is a foundation, not production-hardened: add CAPTCHA/rate limits to key generation and use a reservation/authorization endpoint before Telegram upload to prevent upload-before-deduction and concurrent submissions. A device ID can be spoofed; account authentication is stronger.
Never embed Telegram bot tokens in the APK; keep them server-side.
